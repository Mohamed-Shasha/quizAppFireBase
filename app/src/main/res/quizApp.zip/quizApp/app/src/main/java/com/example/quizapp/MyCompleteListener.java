package com.example.quizapp;

public interface MyCompleteListener {
    void onSuccess();
    void onFailure();

}
